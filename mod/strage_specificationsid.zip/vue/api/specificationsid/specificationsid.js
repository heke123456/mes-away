import request from '@/utils/request'

// 查询规格类型列表
export function listSpecificationsid(query) {
  return request({
    url: '/specificationsid/specificationsid/list',
    method: 'get',
    params: query
  })
}

// 查询规格类型详细
export function getSpecificationsid(id) {
  return request({
    url: '/specificationsid/specificationsid/' + id,
    method: 'get'
  })
}

// 新增规格类型
export function addSpecificationsid(data) {
  return request({
    url: '/specificationsid/specificationsid',
    method: 'post',
    data: data
  })
}

// 修改规格类型
export function updateSpecificationsid(data) {
  return request({
    url: '/specificationsid/specificationsid',
    method: 'put',
    data: data
  })
}

// 删除规格类型
export function delSpecificationsid(id) {
  return request({
    url: '/specificationsid/specificationsid/' + id,
    method: 'delete'
  })
}
