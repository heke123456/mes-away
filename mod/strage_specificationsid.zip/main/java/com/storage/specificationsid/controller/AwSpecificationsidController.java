package com.storage.specificationsid.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.storage.specificationsid.domain.AwSpecificationsid;
import com.storage.specificationsid.service.IAwSpecificationsidService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 规格类型Controller
 * 
 * @author awise
 * @date 2023-07-27
 */
@RestController
@RequestMapping("/specificationsid/specificationsid")
public class AwSpecificationsidController extends BaseController
{
    @Autowired
    private IAwSpecificationsidService awSpecificationsidService;

    /**
     * 查询规格类型列表
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:list')")
    @GetMapping("/list")
    public TableDataInfo list(AwSpecificationsid awSpecificationsid)
    {
        startPage();
        List<AwSpecificationsid> list = awSpecificationsidService.selectAwSpecificationsidList(awSpecificationsid);
        return getDataTable(list);
    }

    /**
     * 导出规格类型列表
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:export')")
    @Log(title = "规格类型", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, AwSpecificationsid awSpecificationsid)
    {
        List<AwSpecificationsid> list = awSpecificationsidService.selectAwSpecificationsidList(awSpecificationsid);
        ExcelUtil<AwSpecificationsid> util = new ExcelUtil<AwSpecificationsid>(AwSpecificationsid.class);
        util.exportExcel(response, list, "规格类型数据");
    }

    /**
     * 获取规格类型详细信息
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") String id)
    {
        return success(awSpecificationsidService.selectAwSpecificationsidById(id));
    }

    /**
     * 新增规格类型
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:add')")
    @Log(title = "规格类型", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody AwSpecificationsid awSpecificationsid)
    {
        return toAjax(awSpecificationsidService.insertAwSpecificationsid(awSpecificationsid));
    }

    /**
     * 修改规格类型
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:edit')")
    @Log(title = "规格类型", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody AwSpecificationsid awSpecificationsid)
    {
        return toAjax(awSpecificationsidService.updateAwSpecificationsid(awSpecificationsid));
    }

    /**
     * 删除规格类型
     */
    @PreAuthorize("@ss.hasPermi('specificationsid:specificationsid:remove')")
    @Log(title = "规格类型", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable String[] ids)
    {
        return toAjax(awSpecificationsidService.deleteAwSpecificationsidByIds(ids));
    }
}
