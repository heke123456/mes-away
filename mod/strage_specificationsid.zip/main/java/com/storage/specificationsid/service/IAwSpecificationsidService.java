package com.storage.specificationsid.service;

import java.util.List;
import com.storage.specificationsid.domain.AwSpecificationsid;

/**
 * 规格类型Service接口
 * 
 * @author awise
 * @date 2023-07-27
 */
public interface IAwSpecificationsidService 
{
    /**
     * 查询规格类型
     * 
     * @param id 规格类型主键
     * @return 规格类型
     */
    public AwSpecificationsid selectAwSpecificationsidById(String id);

    /**
     * 查询规格类型列表
     * 
     * @param awSpecificationsid 规格类型
     * @return 规格类型集合
     */
    public List<AwSpecificationsid> selectAwSpecificationsidList(AwSpecificationsid awSpecificationsid);

    /**
     * 新增规格类型
     * 
     * @param awSpecificationsid 规格类型
     * @return 结果
     */
    public int insertAwSpecificationsid(AwSpecificationsid awSpecificationsid);

    /**
     * 修改规格类型
     * 
     * @param awSpecificationsid 规格类型
     * @return 结果
     */
    public int updateAwSpecificationsid(AwSpecificationsid awSpecificationsid);

    /**
     * 批量删除规格类型
     * 
     * @param ids 需要删除的规格类型主键集合
     * @return 结果
     */
    public int deleteAwSpecificationsidByIds(String[] ids);

    /**
     * 删除规格类型信息
     * 
     * @param id 规格类型主键
     * @return 结果
     */
    public int deleteAwSpecificationsidById(String id);
}
