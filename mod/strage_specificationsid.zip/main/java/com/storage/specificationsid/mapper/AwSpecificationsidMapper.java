package com.storage.specificationsid.mapper;

import java.util.List;
import com.storage.specificationsid.domain.AwSpecificationsid;

/**
 * 规格类型Mapper接口
 * 
 * @author awise
 * @date 2023-07-27
 */
public interface AwSpecificationsidMapper 
{
    /**
     * 查询规格类型
     * 
     * @param id 规格类型主键
     * @return 规格类型
     */
    public AwSpecificationsid selectAwSpecificationsidById(String id);

    /**
     * 查询规格类型列表
     * 
     * @param awSpecificationsid 规格类型
     * @return 规格类型集合
     */
    public List<AwSpecificationsid> selectAwSpecificationsidList(AwSpecificationsid awSpecificationsid);

    /**
     * 新增规格类型
     * 
     * @param awSpecificationsid 规格类型
     * @return 结果
     */
    public int insertAwSpecificationsid(AwSpecificationsid awSpecificationsid);

    /**
     * 修改规格类型
     * 
     * @param awSpecificationsid 规格类型
     * @return 结果
     */
    public int updateAwSpecificationsid(AwSpecificationsid awSpecificationsid);

    /**
     * 删除规格类型
     * 
     * @param id 规格类型主键
     * @return 结果
     */
    public int deleteAwSpecificationsidById(String id);

    /**
     * 批量删除规格类型
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteAwSpecificationsidByIds(String[] ids);
}
