-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细', '3', '1', 'detailmaterialsubscription', 'order/detailmaterialsubscription/index', 1, 0, 'C', '0', '0', 'order:detailmaterialsubscription:list', '#', 'admin', sysdate(), '', null, '申购材料详细菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'order:detailmaterialsubscription:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'order:detailmaterialsubscription:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'order:detailmaterialsubscription:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'order:detailmaterialsubscription:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料详细导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'order:detailmaterialsubscription:export',       '#', 'admin', sysdate(), '', null, '');