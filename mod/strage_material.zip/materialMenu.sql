-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息', '2017', '1', 'material', 'storage/material/index', 1, 0, 'C', '0', '0', 'storage:material:list', '#', 'admin', sysdate(), '', null, '材料基本信息菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'storage:material:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'storage:material:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'storage:material:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'storage:material:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料基本信息导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'storage:material:export',       '#', 'admin', sysdate(), '', null, '');