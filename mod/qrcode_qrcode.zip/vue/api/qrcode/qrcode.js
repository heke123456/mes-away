import request from '@/utils/request'

// 查询二维码列表
export function listQrcode(query) {
  return request({
    url: '/qrcode/qrcode/list',
    method: 'get',
    params: query
  })
}

// 查询二维码详细
export function getQrcode(id) {
  return request({
    url: '/qrcode/qrcode/' + id,
    method: 'get'
  })
}

// 新增二维码
export function addQrcode(data) {
  return request({
    url: '/qrcode/qrcode',
    method: 'post',
    data: data
  })
}

// 修改二维码
export function updateQrcode(data) {
  return request({
    url: '/qrcode/qrcode',
    method: 'put',
    data: data
  })
}

// 删除二维码
export function delQrcode(id) {
  return request({
    url: '/qrcode/qrcode/' + id,
    method: 'delete'
  })
}
