-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料', '3', '1', 'MaterialListOfTechnology', 'produce/MaterialListOfTechnology/index', 1, 0, 'C', '0', '0', 'produce:MaterialListOfTechnology:list', '#', 'admin', sysdate(), '', null, '需求材料菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'produce:MaterialListOfTechnology:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'produce:MaterialListOfTechnology:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'produce:MaterialListOfTechnology:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'produce:MaterialListOfTechnology:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('需求材料导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'produce:MaterialListOfTechnology:export',       '#', 'admin', sysdate(), '', null, '');