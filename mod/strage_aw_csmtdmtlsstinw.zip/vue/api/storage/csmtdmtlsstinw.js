import request from '@/utils/request'

// 查询客供材料入库列表
export function listCsmtdmtlsstinw(query) {
  return request({
    url: '/storage/csmtdmtlsstinw/list',
    method: 'get',
    params: query
  })
}

// 查询客供材料入库详细
export function getCsmtdmtlsstinw(id) {
  return request({
    url: '/storage/csmtdmtlsstinw/' + id,
    method: 'get'
  })
}

// 新增客供材料入库
export function addCsmtdmtlsstinw(data) {
  return request({
    url: '/storage/csmtdmtlsstinw',
    method: 'post',
    data: data
  })
}

// 修改客供材料入库
export function updateCsmtdmtlsstinw(data) {
  return request({
    url: '/storage/csmtdmtlsstinw',
    method: 'put',
    data: data
  })
}

// 删除客供材料入库
export function delCsmtdmtlsstinw(id) {
  return request({
    url: '/storage/csmtdmtlsstinw/' + id,
    method: 'delete'
  })
}
