package com.awise.order.domain;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

/**
 * 订单对象 aw_saleorder
 * 
 * @author awise
 * @date 2023-08-03
 */
public class AwSaleorder extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 订单id#日期+编号# */
    private String id;

    /** 创建人 */
    @Excel(name = "创建人")
    private String createUseID;

    /** 需求数量 */
    @Excel(name = "需求数量")
    private Long number;

    /** 要求交期 */
    @Excel(name = "要求交期")
    private String requiredDeliveryTime;

    /** 客户信息 */
    @Excel(name = "客户信息")
    private String customerID;

    /** 产品信息 */
    @Excel(name = "产品信息")
    private String productID;

    /** 合同信息 */
    @Excel(name = "合同信息")
    private String contractID;

    /** 发票信息 */
    @Excel(name = "发票信息")
    private String invoiceID;

    /** 当前订单状态 */
    @Excel(name = "当前订单状态")
    private String state;

    /** 删除否 */
    @Excel(name = "删除否")
    private String isDel;

    public void setId(String id) 
    {
        this.id = id;
    }

    public String getId() 
    {
        return id;
    }
    public void setCreateUseID(String createUseID) 
    {
        this.createUseID = createUseID;
    }

    public String getCreateUseID() 
    {
        return createUseID;
    }
    public void setNumber(Long number) 
    {
        this.number = number;
    }

    public Long getNumber() 
    {
        return number;
    }
    public void setRequiredDeliveryTime(String requiredDeliveryTime) 
    {
        this.requiredDeliveryTime = requiredDeliveryTime;
    }

    public String getRequiredDeliveryTime() 
    {
        return requiredDeliveryTime;
    }
    public void setCustomerID(String customerID) 
    {
        this.customerID = customerID;
    }

    public String getCustomerID() 
    {
        return customerID;
    }
    public void setProductID(String productID) 
    {
        this.productID = productID;
    }

    public String getProductID() 
    {
        return productID;
    }
    public void setContractID(String contractID) 
    {
        this.contractID = contractID;
    }

    public String getContractID() 
    {
        return contractID;
    }
    public void setInvoiceID(String invoiceID) 
    {
        this.invoiceID = invoiceID;
    }

    public String getInvoiceID() 
    {
        return invoiceID;
    }
    public void setState(String state) 
    {
        this.state = state;
    }

    public String getState() 
    {
        return state;
    }
    public void setIsDel(String isDel) 
    {
        this.isDel = isDel;
    }

    public String getIsDel() 
    {
        return isDel;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("createtime", getCreatetime())
            .append("createUseID", getCreateUseID())
            .append("number", getNumber())
            .append("requiredDeliveryTime", getRequiredDeliveryTime())
            .append("customerID", getCustomerID())
            .append("productID", getProductID())
            .append("contractID", getContractID())
            .append("invoiceID", getInvoiceID())
            .append("state", getState())
            .append("isDel", getIsDel())
            .toString();
    }
}
