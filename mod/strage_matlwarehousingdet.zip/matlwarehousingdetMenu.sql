-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细', '3', '1', 'matlwarehousingdet', 'storage/matlwarehousingdet/index', 1, 0, 'C', '0', '0', 'storage:matlwarehousingdet:list', '#', 'admin', sysdate(), '', null, '材料入库详细菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'storage:matlwarehousingdet:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'storage:matlwarehousingdet:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'storage:matlwarehousingdet:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'storage:matlwarehousingdet:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('材料入库详细导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'storage:matlwarehousingdet:export',       '#', 'admin', sysdate(), '', null, '');