import request from '@/utils/request'

// 查询合作方信息列表
export function listPartner(query) {
  return request({
    url: '/comprehensive/partner/list',
    method: 'get',
    params: query
  })
}

// 查询合作方信息详细
export function getPartner(ID) {
  return request({
    url: '/comprehensive/partner/' + ID,
    method: 'get'
  })
}

// 新增合作方信息
export function addPartner(data) {
  return request({
    url: '/comprehensive/partner',
    method: 'post',
    data: data
  })
}

// 修改合作方信息
export function updatePartner(data) {
  return request({
    url: '/comprehensive/partner',
    method: 'put',
    data: data
  })
}

// 删除合作方信息
export function delPartner(ID) {
  return request({
    url: '/comprehensive/partner/' + ID,
    method: 'delete'
  })
}
