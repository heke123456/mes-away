-- 菜单 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料', '3', '1', 'materialsubscription', 'order/materialsubscription/index', 1, 0, 'C', '0', '0', 'order:materialsubscription:list', '#', 'admin', sysdate(), '', null, '申购材料菜单');

-- 按钮父菜单ID
SELECT @parentId := LAST_INSERT_ID();

-- 按钮 SQL
insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料查询', @parentId, '1',  '#', '', 1, 0, 'F', '0', '0', 'order:materialsubscription:query',        '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料新增', @parentId, '2',  '#', '', 1, 0, 'F', '0', '0', 'order:materialsubscription:add',          '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料修改', @parentId, '3',  '#', '', 1, 0, 'F', '0', '0', 'order:materialsubscription:edit',         '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料删除', @parentId, '4',  '#', '', 1, 0, 'F', '0', '0', 'order:materialsubscription:remove',       '#', 'admin', sysdate(), '', null, '');

insert into sys_menu (menu_name, parent_id, order_num, path, component, is_frame, is_cache, menu_type, visible, status, perms, icon, create_by, create_time, update_by, update_time, remark)
values('申购材料导出', @parentId, '5',  '#', '', 1, 0, 'F', '0', '0', 'order:materialsubscription:export',       '#', 'admin', sysdate(), '', null, '');