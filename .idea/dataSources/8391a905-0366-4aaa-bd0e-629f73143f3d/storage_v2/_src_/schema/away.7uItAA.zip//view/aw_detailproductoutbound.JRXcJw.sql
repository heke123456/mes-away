create definer = root@`%` view aw_detailproductoutbound as
select `away`.`aw_productoutbound`.`id`                     AS `id`,
       `away`.`aw_productoutbound`.`deliveryNoteID`         AS `deliveryNoteID`,
       `away`.`aw_productoutbound`.`productID`              AS `productID`,
       `away`.`aw_product`.`name`                           AS `productname`,
       `away`.`aw_productoutbound`.`shippingInspectionID`   AS `shippingInspectionID`,
       `away`.`aw_shippinginspection`.`shipmentQuantity`    AS `shipmentQuantity`,
       `away`.`aw_shippinginspection`.`detectionQuantity`   AS `detectionQuantity`,
       `away`.`aw_shippinginspection`.`qualifiedQuantity`   AS `qualifiedQuantity`,
       `away`.`aw_shippinginspection`.`unqualifiedQuantity` AS `unqualifiedQuantity`,
       `away`.`aw_shippinginspection`.`testResult`          AS `testResult`,
       `away`.`aw_shippinginspection`.`testDate`            AS `testDate`,
       `away`.`aw_shippinginspection`.`testingPersonnel`    AS `testingPersonnel`,
       `away`.`aw_productoutbound`.`receiptQuantity`        AS `receiptQuantity`,
       `away`.`aw_productoutbound`.`contractID`             AS `contractID`,
       `away`.`aw_partner`.`name`                           AS `customname`
from (((`away`.`aw_productoutbound` join `away`.`aw_product`
        on ((`away`.`aw_productoutbound`.`productID` = `away`.`aw_product`.`id`))) join `away`.`aw_shippinginspection`
       on (((`away`.`aw_productoutbound`.`shippingInspectionID` = `away`.`aw_shippinginspection`.`id`) and
            (`away`.`aw_product`.`id` = `away`.`aw_shippinginspection`.`productID`)))) join `away`.`aw_partner`
      on ((`away`.`aw_shippinginspection`.`contractID` = `away`.`aw_partner`.`id`)));

-- comment on column aw_detailproductoutbound.id not supported: id

-- comment on column aw_detailproductoutbound.deliveryNoteID not supported: 出库单编号

-- comment on column aw_detailproductoutbound.productID not supported: 产品图号

-- comment on column aw_detailproductoutbound.productname not supported: 产品名称

-- comment on column aw_detailproductoutbound.shippingInspectionID not supported: 出货检验编号

-- comment on column aw_detailproductoutbound.shipmentQuantity not supported: 出货数量

-- comment on column aw_detailproductoutbound.detectionQuantity not supported: 检测数量

-- comment on column aw_detailproductoutbound.qualifiedQuantity not supported: 合格数量

-- comment on column aw_detailproductoutbound.unqualifiedQuantity not supported: 不合格数量

-- comment on column aw_detailproductoutbound.testResult not supported: 检测结果

-- comment on column aw_detailproductoutbound.testDate not supported: 检测日期

-- comment on column aw_detailproductoutbound.testingPersonnel not supported: 检测人员

-- comment on column aw_detailproductoutbound.receiptQuantity not supported: 出库数量

-- comment on column aw_detailproductoutbound.contractID not supported: 客户编号

-- comment on column aw_detailproductoutbound.customname not supported: 实体姓名

