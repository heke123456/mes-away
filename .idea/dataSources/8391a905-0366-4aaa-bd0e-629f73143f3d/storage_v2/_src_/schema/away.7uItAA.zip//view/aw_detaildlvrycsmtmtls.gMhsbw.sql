create definer = root@`%` view aw_detaildlvrycsmtmtls as
select `away`.`aw_dlvrycsmtmtls`.`id`                      AS `id`,
       `away`.`aw_dlvrycsmtmtls`.`deliverynotesID`         AS `deliverynotesID`,
       `away`.`aw_dlvrycsmtmtls`.`materialID`              AS `materialID`,
       `aw_basicinformationofmaterials`.`name`             AS `materialName`,
       `away`.`aw_productiontasks`.`productionTasksFormID` AS `productionTasksFormID`,
       `away`.`aw_dlvrycsmtmtls`.`productionTasksID`       AS `productionTasksID`,
       `away`.`aw_dlvrycsmtmtls`.`processingTechnologyID`  AS `processingTechnologyID`,
       `away`.`aw_processrequirementmateriallist`.`id`     AS `prmID`,
       `away`.`aw_dlvrycsmtmtls`.`outboundQuantity`        AS `outboundQuantity`,
       `away`.`aw_dlvrycsmtmtls`.`notes`                   AS `notes`
from (((`away`.`aw_dlvrycsmtmtls` join `away`.`aw_basicinformationofmaterials`
        on ((`away`.`aw_dlvrycsmtmtls`.`materialID` =
             `aw_basicinformationofmaterials`.`id`))) join `away`.`aw_processrequirementmateriallist`
       on ((`away`.`aw_dlvrycsmtmtls`.`processingTechnologyID` =
            `away`.`aw_processrequirementmateriallist`.`processingTechnologyID`))) join `away`.`aw_productiontasks`
      on ((`away`.`aw_dlvrycsmtmtls`.`productionTasksID` = `away`.`aw_productiontasks`.`id`)));

-- comment on column aw_detaildlvrycsmtmtls.id not supported: id

-- comment on column aw_detaildlvrycsmtmtls.deliverynotesID not supported: 出库单编号

-- comment on column aw_detaildlvrycsmtmtls.materialID not supported: 材料基础信息编号

-- comment on column aw_detaildlvrycsmtmtls.materialName not supported: 材料名称

-- comment on column aw_detaildlvrycsmtmtls.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_detaildlvrycsmtmtls.productionTasksID not supported: 任务编号

-- comment on column aw_detaildlvrycsmtmtls.processingTechnologyID not supported: 工艺编号

-- comment on column aw_detaildlvrycsmtmtls.prmID not supported: id

-- comment on column aw_detaildlvrycsmtmtls.outboundQuantity not supported: 出库数量

-- comment on column aw_detaildlvrycsmtmtls.notes not supported: 备注

