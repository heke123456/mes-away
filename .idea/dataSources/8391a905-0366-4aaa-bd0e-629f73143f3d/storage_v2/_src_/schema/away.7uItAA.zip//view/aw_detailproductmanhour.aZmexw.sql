create definer = root@localhost view aw_detailproductmanhour as
select `away`.`aw_productmanhour`.`id`                        AS `id`,
       `away`.`aw_productmanhour`.`saleorderID`               AS `saleorderID`,
       `away`.`aw_productmanhour`.`productiontasksID`         AS `productiontasksID`,
       `away`.`aw_productmanhour`.`processingprocess`         AS `processingprocess`,
       `away`.`aw_productmanhour`.`manhourName`               AS `manhourName`,
       `away`.`aw_productmanhour`.`workClass`                 AS `workClass`,
       `away`.`aw_productmanhour`.`PlatformNumber`            AS `PlatformNumber`,
       `away`.`aw_productmanhour`.`qualifiedQuantity`         AS `qualifiedQuantity`,
       `away`.`aw_productmanhour`.`scrapQuantity`             AS `scrapQuantity`,
       `away`.`aw_productmanhour`.`lotNumber`                 AS `lotNumber`,
       `away`.`aw_productmanhour`.`manhoursTime`              AS `manhoursTime`,
       `away`.`aw_productmanhour`.`formulateName1`            AS `formulateName1`,
       `away`.`aw_productmanhour`.`handlers1`                 AS `handlers1`,
       `away`.`aw_productmanhour`.`beginTime1`                AS `beginTime1`,
       `away`.`aw_productmanhour`.`endTime1`                  AS `endTime1`,
       `away`.`aw_productmanhour`.`actualTime1`               AS `actualTime1`,
       `away`.`aw_productmanhour`.`formulateName2`            AS `formulateName2`,
       `away`.`aw_productmanhour`.`handlers2`                 AS `handlers2`,
       `away`.`aw_productmanhour`.`beginTime2`                AS `beginTime2`,
       `away`.`aw_productmanhour`.`endTime2`                  AS `endTime2`,
       `away`.`aw_productmanhour`.`actualTime2`               AS `actualTime2`,
       `away`.`aw_saleorder`.`number`                         AS `number`,
       `away`.`aw_productiontasks`.`productionTasksFormID`    AS `productionTasksFormID`,
       `away`.`aw_processingprocess`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_processingprocess`.`name`                   AS `name`,
       `away`.`aw_processingprocess`.`preparationHours`       AS `preparationHours`,
       `away`.`aw_processingprocess`.`taktTime`               AS `taktTime`
from (((`away`.`aw_productmanhour` join `away`.`aw_saleorder`
        on ((`away`.`aw_productmanhour`.`saleorderID` = `away`.`aw_saleorder`.`id`))) join `away`.`aw_productiontasks`
       on ((`away`.`aw_productmanhour`.`productiontasksID` =
            `away`.`aw_productiontasks`.`id`))) join `away`.`aw_processingprocess`
      on ((`away`.`aw_productmanhour`.`processingprocess` = `away`.`aw_processingprocess`.`id`)));

-- comment on column aw_detailproductmanhour.id not supported: 工时id

-- comment on column aw_detailproductmanhour.saleorderID not supported: 订单id

-- comment on column aw_detailproductmanhour.productiontasksID not supported: 生产任务id

-- comment on column aw_detailproductmanhour.processingprocess not supported: 加工工序

-- comment on column aw_detailproductmanhour.manhourName not supported: 工时名字

-- comment on column aw_detailproductmanhour.workClass not supported: 班别

-- comment on column aw_detailproductmanhour.PlatformNumber not supported: 机台号

-- comment on column aw_detailproductmanhour.qualifiedQuantity not supported: 合格数量

-- comment on column aw_detailproductmanhour.scrapQuantity not supported: 报废数量

-- comment on column aw_detailproductmanhour.lotNumber not supported: 批次号

-- comment on column aw_detailproductmanhour.manhoursTime not supported: 工时时间

-- comment on column aw_detailproductmanhour.formulateName1 not supported: 制定者名字

-- comment on column aw_detailproductmanhour.handlers1 not supported: 操作者

-- comment on column aw_detailproductmanhour.beginTime1 not supported: 开始时间

-- comment on column aw_detailproductmanhour.endTime1 not supported: 最后时间

-- comment on column aw_detailproductmanhour.actualTime1 not supported: 实际时间

-- comment on column aw_detailproductmanhour.formulateName2 not supported: 制定者名字

-- comment on column aw_detailproductmanhour.handlers2 not supported: 操作者

-- comment on column aw_detailproductmanhour.beginTime2 not supported: 开始时间

-- comment on column aw_detailproductmanhour.endTime2 not supported: 最后时间

-- comment on column aw_detailproductmanhour.actualTime2 not supported: 实际时间

-- comment on column aw_detailproductmanhour.number not supported: 需求数量#要求大于0#

-- comment on column aw_detailproductmanhour.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_detailproductmanhour.processingTechnologyID not supported: 加工工艺信息

-- comment on column aw_detailproductmanhour.name not supported: 工序名称

-- comment on column aw_detailproductmanhour.preparationHours not supported: 准备工时

-- comment on column aw_detailproductmanhour.taktTime not supported: 单件工时

