create definer = root@`%` view aw_detailcsmtdmtlsstinw as
select `away`.`aw_csmtdmtlsstinw`.`id`                     AS `id`,
       `away`.`aw_csmtdmtlsstinw`.`warehouseEntryID`       AS `warehouseEntryID`,
       `away`.`aw_csmtdmtlsstinw`.`materialID`             AS `materialID`,
       `aw_basicinformationofmaterials`.`name`             AS `materialName`,
       `away`.`aw_csmtdmtlsstinw`.`mthd`                   AS `mthd`,
       `away`.`aw_csmtdmtlsstinw`.`furnaceBatchNumber`     AS `furnaceBatchNumber`,
       `away`.`aw_csmtdmtlsstinw`.`dataType`               AS `dataType`,
       `away`.`aw_csmtdmtlsstinw`.`dataAttachment`         AS `dataAttachment`,
       `away`.`aw_csmtdmtlsstinw`.`receiptQuantity`        AS `receiptQuantity`,
       `away`.`aw_productiontasks`.`productionTasksFormID` AS `productionTasksFormID`,
       `away`.`aw_csmtdmtlsstinw`.`productionTasksID`      AS `productionTasksID`,
       `aw_salesorderdetails`.`customerID`                 AS `customerID`,
       `aw_salesorderdetails`.`name`                       AS `customername`,
       `aw_salesorderdetails`.`productID`                  AS `productID`,
       `aw_salesorderdetails`.`productName`                AS `productName`,
       `away`.`aw_csmtdmtlsstinw`.`sampleURL`              AS `sampleURL`,
       `away`.`aw_csmtdmtlsstinw`.`notes`                  AS `notes`
from (((`away`.`aw_csmtdmtlsstinw` join `away`.`aw_basicinformationofmaterials`
        on ((`away`.`aw_csmtdmtlsstinw`.`materialID` =
             `aw_basicinformationofmaterials`.`id`))) join `away`.`aw_productiontasks`
       on ((`away`.`aw_csmtdmtlsstinw`.`productionTasksID` =
            `away`.`aw_productiontasks`.`id`))) join `away`.`aw_salesorderdetails`
      on ((`away`.`aw_productiontasks`.`saleOrderID` = `aw_salesorderdetails`.`id`)));

-- comment on column aw_detailcsmtdmtlsstinw.id not supported: id

-- comment on column aw_detailcsmtdmtlsstinw.warehouseEntryID not supported: 入库单编号

-- comment on column aw_detailcsmtdmtlsstinw.materialID not supported: 材料信息编号

-- comment on column aw_detailcsmtdmtlsstinw.materialName not supported: 材料名称

-- comment on column aw_detailcsmtdmtlsstinw.mthd not supported: 化验号

-- comment on column aw_detailcsmtdmtlsstinw.furnaceBatchNumber not supported: 炉批号

-- comment on column aw_detailcsmtdmtlsstinw.dataType not supported: 资料类型

-- comment on column aw_detailcsmtdmtlsstinw.dataAttachment not supported: 资料附件

-- comment on column aw_detailcsmtdmtlsstinw.receiptQuantity not supported: 入库数量

-- comment on column aw_detailcsmtdmtlsstinw.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_detailcsmtdmtlsstinw.productionTasksID not supported: 任务编号

-- comment on column aw_detailcsmtdmtlsstinw.customerID not supported: 客户信息

-- comment on column aw_detailcsmtdmtlsstinw.customername not supported: 实体姓名

-- comment on column aw_detailcsmtdmtlsstinw.productID not supported: 产品信息

-- comment on column aw_detailcsmtdmtlsstinw.productName not supported: 产品名称

-- comment on column aw_detailcsmtdmtlsstinw.sampleURL not supported: 附样

-- comment on column aw_detailcsmtdmtlsstinw.notes not supported: 备注

