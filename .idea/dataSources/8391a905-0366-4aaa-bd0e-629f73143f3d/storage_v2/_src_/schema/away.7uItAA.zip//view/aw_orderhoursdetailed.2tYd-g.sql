create definer = root@`%` view aw_orderhoursdetailed as
select `away`.`aw_saleorder`.`id`              AS `id`,
       `away`.`aw_saleorder`.`createTime`      AS `createTime`,
       `away`.`aw_saleorder`.`orderDate`       AS `orderDate`,
       `away`.`aw_saleorder`.`number`          AS `number`,
       `away`.`aw_partner`.`name`              AS `name`,
       `away`.`aw_partner`.`unifiedCreditCode` AS `unifiedCreditCode`,
       `away`.`aw_product`.`name`              AS `productName`,
       `away`.`aw_product`.`id`                AS `productID`
from ((`away`.`aw_saleorder` join `away`.`aw_partner`
       on ((`away`.`aw_saleorder`.`customerID` = `away`.`aw_partner`.`id`))) join `away`.`aw_product`
      on ((`away`.`aw_saleorder`.`productID` = `away`.`aw_product`.`id`)));

-- comment on column aw_orderhoursdetailed.id not supported: 订单id#日期+编号#

-- comment on column aw_orderhoursdetailed.createTime not supported: 销售单创建日期

-- comment on column aw_orderhoursdetailed.orderDate not supported: 下单日期

-- comment on column aw_orderhoursdetailed.number not supported: 需求数量#要求大于0#

-- comment on column aw_orderhoursdetailed.name not supported: 实体姓名

-- comment on column aw_orderhoursdetailed.unifiedCreditCode not supported: 社会统一信用代码

-- comment on column aw_orderhoursdetailed.productName not supported: 产品名称

-- comment on column aw_orderhoursdetailed.productID not supported: 产品图号

