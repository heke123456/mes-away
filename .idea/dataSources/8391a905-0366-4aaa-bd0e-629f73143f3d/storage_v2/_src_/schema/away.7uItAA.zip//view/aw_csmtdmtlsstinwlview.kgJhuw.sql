create definer = root@`%` view aw_csmtdmtlsstinwlview as
select `away`.`aw_csmtdmtlsstinwlist`.`warehouseEntryID` AS `warehouseEntryID`,
       `away`.`aw_warehousing`.`warehousingDate`         AS `warehousingDate`,
       `away`.`aw_warehousing`.`creator`                 AS `creator`,
       `away`.`aw_warehousing`.`acceptedBy`              AS `acceptedBy`,
       `away`.`aw_warehousing`.`warehouseKeeper`         AS `warehouseKeeper`,
       `away`.`aw_warehousing`.`operator`                AS `operator`,
       `away`.`aw_warehousing`.`notes`                   AS `notes`,
       `away`.`aw_warehousing`.`status`                  AS `status`
from (`away`.`aw_csmtdmtlsstinwlist` left join `away`.`aw_warehousing`
      on ((`away`.`aw_csmtdmtlsstinwlist`.`warehouseEntryID` = `away`.`aw_warehousing`.`warehouseEntryID`)));

-- comment on column aw_csmtdmtlsstinwlview.warehouseEntryID not supported: 入库单编号

-- comment on column aw_csmtdmtlsstinwlview.warehousingDate not supported: 入库日期

-- comment on column aw_csmtdmtlsstinwlview.creator not supported: 制单人

-- comment on column aw_csmtdmtlsstinwlview.acceptedBy not supported: 验收人

-- comment on column aw_csmtdmtlsstinwlview.warehouseKeeper not supported: 库管员

-- comment on column aw_csmtdmtlsstinwlview.operator not supported: 经办人

-- comment on column aw_csmtdmtlsstinwlview.notes not supported: 备注

-- comment on column aw_csmtdmtlsstinwlview.status not supported: 状态

