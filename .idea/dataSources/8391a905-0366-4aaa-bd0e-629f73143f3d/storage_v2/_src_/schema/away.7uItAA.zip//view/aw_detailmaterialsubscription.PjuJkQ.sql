create definer = root@`%` view aw_detailmaterialsubscription as
select `away`.`aw_materialsubscription`.`materialSubscription`   AS `materialSubscription`,
       `away`.`aw_materialsubscription`.`subscribeID`            AS `subscribeID`,
       `away`.`aw_materialsubscription`.`productionTasksID`      AS `productionTasksID`,
       `away`.`aw_materialsubscription`.`materialID`             AS `materialID`,
       `aw_basicinformationofmaterials`.`name`                   AS `name`,
       `aw_basicinformationofmaterials`.`typeName`               AS `typeName`,
       `aw_basicinformationofmaterials`.`specificationsType`     AS `specificationsType`,
       `aw_basicinformationofmaterials`.`specificationModel`     AS `specificationModel`,
       `aw_basicinformationofmaterials`.`materialDensity`        AS `materialDensity`,
       `away`.`aw_materialsubscription`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_materialsubscription`.`subscriptionQuantity`   AS `subscriptionQuantity`,
       `away`.`aw_materialsubscription`.`requiredDate`           AS `requiredDate`,
       `away`.`aw_materialsubscription`.`sampleURL`              AS `sampleURL`,
       `away`.`aw_materialsubscription`.`note`                   AS `note`
from (`away`.`aw_materialsubscription` join `away`.`aw_basicinformationofmaterials`
      on ((`away`.`aw_materialsubscription`.`materialID` = `aw_basicinformationofmaterials`.`id`)));

-- comment on column aw_detailmaterialsubscription.materialSubscription not supported: 申购材料编号

-- comment on column aw_detailmaterialsubscription.subscribeID not supported: 申购单编号

-- comment on column aw_detailmaterialsubscription.productionTasksID not supported: 任务编号

-- comment on column aw_detailmaterialsubscription.materialID not supported: 材料基础信息编号

-- comment on column aw_detailmaterialsubscription.name not supported: 材料名称

-- comment on column aw_detailmaterialsubscription.typeName not supported: 类别名称

-- comment on column aw_detailmaterialsubscription.specificationsType not supported: 规格类型

-- comment on column aw_detailmaterialsubscription.specificationModel not supported: 规格型号

-- comment on column aw_detailmaterialsubscription.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_detailmaterialsubscription.processingTechnologyID not supported: 工艺编号

-- comment on column aw_detailmaterialsubscription.subscriptionQuantity not supported: 申购数量

-- comment on column aw_detailmaterialsubscription.requiredDate not supported: 需用日期

-- comment on column aw_detailmaterialsubscription.sampleURL not supported: 附样

-- comment on column aw_detailmaterialsubscription.note not supported: 备注

