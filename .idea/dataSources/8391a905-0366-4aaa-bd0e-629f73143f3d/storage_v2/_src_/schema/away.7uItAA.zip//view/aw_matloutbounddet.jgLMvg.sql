create definer = root@`%` view aw_matloutbounddet as
select `away`.`aw_localmaterialoutbound`.`id`                     AS `id`,
       `away`.`aw_localmaterialoutbound`.`deliveryNoteID`         AS `deliveryNoteID`,
       `away`.`aw_localmaterialoutbound`.`materialID`             AS `materialID`,
       `aw_basicinformationofmaterials`.`name`                    AS `name`,
       `aw_basicinformationofmaterials`.`typeName`                AS `typeName`,
       `aw_basicinformationofmaterials`.`specificationsType`      AS `specificationsType`,
       `aw_basicinformationofmaterials`.`specificationModel`      AS `specificationModel`,
       `away`.`aw_localmaterialoutbound`.`productionTasksID`      AS `productionTasksID`,
       `away`.`aw_localmaterialoutbound`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_localmaterialoutbound`.`outboundQuantity`       AS `outboundQuantity`,
       `away`.`aw_localmaterialoutbound`.`notes`                  AS `notes`
from (`away`.`aw_localmaterialoutbound` join `away`.`aw_basicinformationofmaterials`
      on ((`away`.`aw_localmaterialoutbound`.`materialID` = `aw_basicinformationofmaterials`.`id`)));

-- comment on column aw_matloutbounddet.id not supported: id

-- comment on column aw_matloutbounddet.deliveryNoteID not supported: 出库单编号

-- comment on column aw_matloutbounddet.materialID not supported: 材料基础信息编号

-- comment on column aw_matloutbounddet.name not supported: 材料名称

-- comment on column aw_matloutbounddet.typeName not supported: 类别名称

-- comment on column aw_matloutbounddet.specificationsType not supported: 规格类型

-- comment on column aw_matloutbounddet.specificationModel not supported: 规格型号

-- comment on column aw_matloutbounddet.productionTasksID not supported: 任务编号

-- comment on column aw_matloutbounddet.processingTechnologyID not supported: 工艺编号

-- comment on column aw_matloutbounddet.outboundQuantity not supported: 出库数量

-- comment on column aw_matloutbounddet.notes not supported: 备注

