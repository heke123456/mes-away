create definer = root@`%` view aw_detailproductwarehousing as
select `away`.`aw_productstorage`.`id`                          AS `id`,
       `away`.`aw_productstorage`.`warehouseEntryID`            AS `warehouseEntryID`,
       `away`.`aw_productstorage`.`productID`                   AS `productID`,
       `away`.`aw_productstorage`.`receiptQuantity`             AS `receiptQuantity`,
       `away`.`aw_productstorage`.`FinishedProductInspectionID` AS `FinishedProductInspectionID`,
       `away`.`aw_finishedproductinspection`.`testResult`       AS `testResult`,
       `away`.`aw_productstorage`.`notes`                       AS `notes`
from (`away`.`aw_productstorage` left join `away`.`aw_finishedproductinspection`
      on ((`away`.`aw_productstorage`.`FinishedProductInspectionID` = `away`.`aw_finishedproductinspection`.`id`)));

-- comment on column aw_detailproductwarehousing.id not supported: id

-- comment on column aw_detailproductwarehousing.warehouseEntryID not supported: 产品入库单编号

-- comment on column aw_detailproductwarehousing.productID not supported: 产品图号

-- comment on column aw_detailproductwarehousing.receiptQuantity not supported: 入库数量

-- comment on column aw_detailproductwarehousing.FinishedProductInspectionID not supported: 成品检验编号

-- comment on column aw_detailproductwarehousing.testResult not supported: 检测结果

-- comment on column aw_detailproductwarehousing.notes not supported: 备注

