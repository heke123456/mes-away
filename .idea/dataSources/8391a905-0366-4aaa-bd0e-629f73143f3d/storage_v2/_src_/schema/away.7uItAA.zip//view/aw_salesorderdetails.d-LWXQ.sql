create definer = root@`%` view aw_salesorderdetails as
select `away`.`aw_saleorder`.`id`                            AS `id`,
       `away`.`aw_saleorder`.`createTime`                    AS `createTime`,
       `away`.`aw_saleorder`.`createUserName`                AS `createUserName`,
       `away`.`aw_saleorder`.`orderDate`                     AS `orderDate`,
       `away`.`aw_saleorder`.`number`                        AS `number`,
       `away`.`aw_saleorder`.`requiredDeliveryTime`          AS `requiredDeliveryTime`,
       `away`.`aw_saleorder`.`iscustomersuppliedmaterials`   AS `iscustomersuppliedmaterials`,
       `away`.`aw_saleorder`.`state`                         AS `state`,
       `away`.`aw_saleorder`.`note`                          AS `note`,
       `away`.`aw_saleorder`.`isDel`                         AS `isDel`,
       `away`.`aw_saleorder`.`customerID`                    AS `customerID`,
       `away`.`aw_partner`.`name`                            AS `name`,
       `away`.`aw_partner`.`nameAbbrevation`                 AS `nameAbbrevation`,
       `away`.`aw_partner`.`unifiedCreditCode`               AS `unifiedCreditCode`,
       `away`.`aw_saleorder`.`productID`                     AS `productID`,
       `away`.`aw_product`.`name`                            AS `productName`,
       `away`.`aw_product`.`drawingURL`                      AS `drawingURL`,
       `away`.`aw_saleorder`.`contractID`                    AS `contractID`,
       `away`.`aw_contract`.`money`                          AS `money`,
       `away`.`aw_contract`.`contractURL`                    AS `contractURL`,
       `away`.`aw_saleorder`.`invoiceID`                     AS `invoiceID`,
       `away`.`aw_invoice`.`invoiceType`                     AS `invoiceType`,
       `away`.`aw_invoice`.`invoiceCreateTime`               AS `invoiceCreateTime`,
       `away`.`aw_invoice`.`invoiceNumer`                    AS `invoiceNumer`,
       `away`.`aw_invoice`.`taxRate`                         AS `taxRate`,
       `away`.`aw_invoice`.`taxation`                        AS `taxation`,
       `away`.`aw_invoice`.`salesUnitPriceExcludingTax`      AS `salesUnitPriceExcludingTax`,
       `away`.`aw_invoice`.`salesUnitPriceIncludingTax`      AS `salesUnitPriceIncludingTax`,
       `away`.`aw_invoice`.`consumptionAmountExcludingTax`   AS `consumptionAmountExcludingTax`,
       `away`.`aw_invoice`.`consumptionAmountIncludingTax`   AS `consumptionAmountIncludingTax`,
       `away`.`aw_invoice`.`reconciliationDate`              AS `reconciliationDate`,
       `away`.`aw_invoice`.`customerReconciliationPersonnel` AS `customerReconciliationPersonnel`
from ((((`away`.`aw_saleorder` join `away`.`aw_partner`
         on ((`away`.`aw_saleorder`.`customerID` = `away`.`aw_partner`.`id`))) join `away`.`aw_product`
        on ((`away`.`aw_saleorder`.`productID` = `away`.`aw_product`.`id`))) join `away`.`aw_contract`
       on ((`away`.`aw_saleorder`.`contractID` = `away`.`aw_contract`.`id`))) join `away`.`aw_invoice`
      on ((`away`.`aw_saleorder`.`invoiceID` = `away`.`aw_invoice`.`id`)));

-- comment on column aw_salesorderdetails.id not supported: 订单id#日期+编号#

-- comment on column aw_salesorderdetails.createTime not supported: 销售单创建日期

-- comment on column aw_salesorderdetails.createUserName not supported: 创建人

-- comment on column aw_salesorderdetails.orderDate not supported: 下单日期

-- comment on column aw_salesorderdetails.number not supported: 需求数量#要求大于0#

-- comment on column aw_salesorderdetails.requiredDeliveryTime not supported: 要求交期#时间要晚于当前日期#

-- comment on column aw_salesorderdetails.iscustomersuppliedmaterials not supported: 客供材料否

-- comment on column aw_salesorderdetails.state not supported: 当前订单状态#0为未发布 1为发布 2为暂停 3为完成 4为取消#

-- comment on column aw_salesorderdetails.note not supported: 备注

-- comment on column aw_salesorderdetails.isDel not supported: 删除否#0为存在 1为删除#

-- comment on column aw_salesorderdetails.customerID not supported: 客户信息

-- comment on column aw_salesorderdetails.name not supported: 实体姓名

-- comment on column aw_salesorderdetails.nameAbbrevation not supported: 实体简称

-- comment on column aw_salesorderdetails.unifiedCreditCode not supported: 社会统一信用代码

-- comment on column aw_salesorderdetails.productID not supported: 产品信息

-- comment on column aw_salesorderdetails.productName not supported: 产品名称

-- comment on column aw_salesorderdetails.drawingURL not supported: 产品图纸附件地址URL

-- comment on column aw_salesorderdetails.contractID not supported: 合同信息

-- comment on column aw_salesorderdetails.money not supported: 合同金额

-- comment on column aw_salesorderdetails.contractURL not supported: 合同附件地址URL

-- comment on column aw_salesorderdetails.invoiceID not supported: 发票信息

-- comment on column aw_salesorderdetails.invoiceType not supported: 开票类型

-- comment on column aw_salesorderdetails.invoiceCreateTime not supported: 开票日期

-- comment on column aw_salesorderdetails.invoiceNumer not supported: 开票数量

-- comment on column aw_salesorderdetails.taxRate not supported: 税率

-- comment on column aw_salesorderdetails.taxation not supported: 税费

-- comment on column aw_salesorderdetails.salesUnitPriceExcludingTax not supported: 销售单价(不含税)

-- comment on column aw_salesorderdetails.salesUnitPriceIncludingTax not supported: 销售单价(含税)

-- comment on column aw_salesorderdetails.consumptionAmountExcludingTax not supported: 销售金额(不含税)

-- comment on column aw_salesorderdetails.consumptionAmountIncludingTax not supported: 销售金额(含税)

-- comment on column aw_salesorderdetails.reconciliationDate not supported: 对账日期

-- comment on column aw_salesorderdetails.customerReconciliationPersonnel not supported: 客户对账人员

