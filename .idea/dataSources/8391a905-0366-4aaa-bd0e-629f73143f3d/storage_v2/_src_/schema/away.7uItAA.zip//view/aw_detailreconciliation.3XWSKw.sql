create definer = root@`%` view aw_detailreconciliation as
select `away`.`aw_reconciliation`.`id`                       AS `id`,
       `away`.`aw_reconciliation`.`statementOfAccountID`     AS `statementOfAccountID`,
       `away`.`aw_reconciliation`.`saleorderID`              AS `saleorderID`,
       `aw_basicorderinformation`.`money`                    AS `money`,
       `aw_basicorderinformation`.`name`                     AS `name`,
       `aw_basicorderinformation`.`productName`              AS `productName`,
       `aw_basicorderinformation`.`number`                   AS `number`,
       `away`.`aw_reconciliation`.`numberOfProductsSupplied` AS `numberOfProductsSupplied`,
       `away`.`aw_reconciliation`.`orderAmount`              AS `orderAmount`,
       `away`.`aw_reconciliation`.`amountDue`                AS `amountDue`,
       `away`.`aw_reconciliation`.`outOfPocketAmount`        AS `outOfPocketAmount`,
       `away`.`aw_reconciliation`.`unpaidAmount`             AS `unpaidAmount`,
       `away`.`aw_reconciliation`.`notes`                    AS `notes`,
       `away`.`aw_reconciliation`.`status`                   AS `status`,
       `away`.`aw_reconciliation`.`customerPrice`            AS `customerPrice`,
       `away`.`aw_reconciliation`.`invoicePrice`             AS `invoicePrice`,
       `away`.`aw_reconciliation`.`processPrice`             AS `processPrice`
from (`away`.`aw_reconciliation` join `away`.`aw_basicorderinformation`
      on ((`away`.`aw_reconciliation`.`saleorderID` = `aw_basicorderinformation`.`id`)));

-- comment on column aw_detailreconciliation.id not supported: 对账id

-- comment on column aw_detailreconciliation.statementOfAccountID not supported: 对账单Id

-- comment on column aw_detailreconciliation.saleorderID not supported: 订单id

-- comment on column aw_detailreconciliation.money not supported: 合同金额

-- comment on column aw_detailreconciliation.name not supported: 实体姓名

-- comment on column aw_detailreconciliation.productName not supported: 产品名称

-- comment on column aw_detailreconciliation.number not supported: 需求数量#要求大于0#

-- comment on column aw_detailreconciliation.numberOfProductsSupplied not supported: 以供产品数

-- comment on column aw_detailreconciliation.orderAmount not supported: 订单金额

-- comment on column aw_detailreconciliation.amountDue not supported: 应付金额

-- comment on column aw_detailreconciliation.outOfPocketAmount not supported: 实付金额

-- comment on column aw_detailreconciliation.unpaidAmount not supported: 未付金额

-- comment on column aw_detailreconciliation.notes not supported: 备注

-- comment on column aw_detailreconciliation.status not supported: 是否通过

-- comment on column aw_detailreconciliation.customerPrice not supported: 客户价格

-- comment on column aw_detailreconciliation.invoicePrice not supported: 发票价格

-- comment on column aw_detailreconciliation.processPrice not supported: 工艺价格

