create definer = root@`%` view aw_materiallistoftechnology as
select `away`.`aw_processrequirementmateriallist`.`id`                     AS `id`,
       `away`.`aw_processrequirementmateriallist`.`materialID`             AS `materialID`,
       `away`.`aw_processrequirementmateriallist`.`processingTechnologyID` AS `processingTechnologyID`,
       `aw_basicinformationofmaterials`.`name`                             AS `name`,
       `aw_basicinformationofmaterials`.`materialDensity`                  AS `materialDensity`,
       `aw_basicinformationofmaterials`.`notes`                            AS `notes`,
       `aw_basicinformationofmaterials`.`typeName`                         AS `typeName`,
       `aw_basicinformationofmaterials`.`specificationsType`               AS `specificationsType`,
       `aw_basicinformationofmaterials`.`specificationModel`               AS `specificationModel`,
       `away`.`aw_processrequirementmateriallist`.`cuttingSize`            AS `cuttingSize`,
       `away`.`aw_processrequirementmateriallist`.`numberProducibleParts`  AS `numberProducibleParts`
from (`away`.`aw_processrequirementmateriallist` join `away`.`aw_basicinformationofmaterials`
      on ((`away`.`aw_processrequirementmateriallist`.`materialID` = `aw_basicinformationofmaterials`.`id`)));

-- comment on column aw_materiallistoftechnology.id not supported: id

-- comment on column aw_materiallistoftechnology.materialID not supported: 材料基础信息编号

-- comment on column aw_materiallistoftechnology.processingTechnologyID not supported: 工艺编号

-- comment on column aw_materiallistoftechnology.name not supported: 材料名称

-- comment on column aw_materiallistoftechnology.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_materiallistoftechnology.notes not supported: 备注信息

-- comment on column aw_materiallistoftechnology.typeName not supported: 类别名称

-- comment on column aw_materiallistoftechnology.specificationsType not supported: 规格类型

-- comment on column aw_materiallistoftechnology.specificationModel not supported: 规格型号

-- comment on column aw_materiallistoftechnology.cuttingSize not supported: 下料尺寸

-- comment on column aw_materiallistoftechnology.numberProducibleParts not supported: 可制件数

