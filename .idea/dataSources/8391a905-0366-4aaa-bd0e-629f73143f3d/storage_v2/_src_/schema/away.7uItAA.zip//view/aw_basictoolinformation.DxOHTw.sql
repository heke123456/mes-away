create definer = root@`%` view aw_basictoolinformation as
select `away`.`aw_toolinformation`.`id`                AS `id`,
       `away`.`aw_toolinformation`.`name`              AS `name`,
       `away`.`aw_toolinformation`.`typeID`            AS `typeID`,
       `away`.`aw_toolinformation`.`specificationsID`  AS `specificationsID`,
       `away`.`aw_toolinformation`.`unitID`            AS `unitID`,
       `away`.`aw_toolinformation`.`notes`             AS `notes`,
       `away`.`aw_toolclassification`.`name`           AS `typeName`,
       `away`.`aw_units`.`unit`                        AS `uint`,
       `away`.`aw_specifications`.`type`               AS `specificationsType`,
       `away`.`aw_specifications`.`specificationModel` AS `specificationModel`
from (((`away`.`aw_toolinformation` join `away`.`aw_toolclassification`
        on ((`away`.`aw_toolinformation`.`typeID` = `away`.`aw_toolclassification`.`id`))) join `away`.`aw_units`
       on ((`away`.`aw_toolinformation`.`unitID` = `away`.`aw_units`.`id`))) join `away`.`aw_specifications`
      on ((`away`.`aw_toolinformation`.`specificationsID` = `away`.`aw_specifications`.`id`)));

-- comment on column aw_basictoolinformation.id not supported: 刀具编号

-- comment on column aw_basictoolinformation.name not supported: 刀具名称

-- comment on column aw_basictoolinformation.typeID not supported: 刀具分类

-- comment on column aw_basictoolinformation.specificationsID not supported: 刀具规格

-- comment on column aw_basictoolinformation.unitID not supported: 计量单位id

-- comment on column aw_basictoolinformation.notes not supported: 备注信息

-- comment on column aw_basictoolinformation.typeName not supported: 类别名称

-- comment on column aw_basictoolinformation.uint not supported: 计量单位

-- comment on column aw_basictoolinformation.specificationsType not supported: 规格类型

-- comment on column aw_basictoolinformation.specificationModel not supported: 规格型号

