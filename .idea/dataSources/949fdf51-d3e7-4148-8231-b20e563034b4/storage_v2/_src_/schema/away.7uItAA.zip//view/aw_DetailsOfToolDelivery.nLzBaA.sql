create definer = away@`%` view aw_DetailsOfToolDelivery as
select `away`.`aw_ToolOutbound`.`id`                  AS `id`,
       `away`.`aw_ToolOutbound`.`deliveryNoteID`      AS `deliveryNoteID`,
       `away`.`aw_ToolOutbound`.`toolInformationID`   AS `toolInformationID`,
       `away`.`aw_ToolOutbound`.`outboundQuantity`    AS `outboundQuantity`,
       `away`.`aw_ToolOutbound`.`newAndOldTypes`      AS `newAndOldTypes`,
       `away`.`aw_ToolOutbound`.`materialRequisition` AS `materialRequisition`,
       `away`.`aw_ToolOutbound`.`notes`               AS `notes`,
       `aw_BasicToolInformation`.`name`               AS `name`,
       `aw_BasicToolInformation`.`typeName`           AS `typeName`,
       `aw_BasicToolInformation`.`toolPrice`          AS `toolPrice`,
       `aw_BasicToolInformation`.`specificationsType` AS `specificationsType`,
       `aw_BasicToolInformation`.`specificationModel` AS `specificationModel`,
       `aw_BasicToolInformation`.`uint`               AS `uint`
from (`away`.`aw_ToolOutbound` join `away`.`aw_BasicToolInformation`
      on ((`away`.`aw_ToolOutbound`.`toolInformationID` = `aw_BasicToolInformation`.`id`)));

-- comment on column aw_DetailsOfToolDelivery.id not supported: 刀具出库id

-- comment on column aw_DetailsOfToolDelivery.deliveryNoteID not supported: 出库单编号

-- comment on column aw_DetailsOfToolDelivery.toolInformationID not supported: 刀具基本信息编号

-- comment on column aw_DetailsOfToolDelivery.outboundQuantity not supported: 出库数量

-- comment on column aw_DetailsOfToolDelivery.newAndOldTypes not supported: 新旧类型

-- comment on column aw_DetailsOfToolDelivery.materialRequisition not supported: 领用用途

-- comment on column aw_DetailsOfToolDelivery.notes not supported: 备注

-- comment on column aw_DetailsOfToolDelivery.name not supported: 刀具名称

-- comment on column aw_DetailsOfToolDelivery.typeName not supported: 类别名称

-- comment on column aw_DetailsOfToolDelivery.toolPrice not supported: 备注信息

-- comment on column aw_DetailsOfToolDelivery.specificationsType not supported: 规格类型

-- comment on column aw_DetailsOfToolDelivery.specificationModel not supported: 规格型号

-- comment on column aw_DetailsOfToolDelivery.uint not supported: 计量单位

