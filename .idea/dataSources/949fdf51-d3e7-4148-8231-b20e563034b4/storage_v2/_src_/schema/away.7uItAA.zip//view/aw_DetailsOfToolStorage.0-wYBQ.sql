create definer = away@`%` view aw_DetailsOfToolStorage as
select `away`.`aw_toolStorage`.`id`                               AS `id`,
       `away`.`aw_toolStorage`.`warehouseEntryID`                 AS `warehouseEntryID`,
       `away`.`aw_toolStorage`.`receiptInvoiceID`                 AS `receiptInvoiceID`,
       `away`.`aw_toolStorage`.`toolInformationID`                AS `toolInformationID`,
       `away`.`aw_toolStorage`.`receiptQuantity`                  AS `receiptQuantity`,
       `away`.`aw_toolStorage`.`manufacturers`                    AS `manufacturers`,
       `away`.`aw_toolStorage`.`notes`                            AS `notes`,
       `away`.`aw_ReceiptInvoice`.`invoiceTaxRate`                AS `invoiceTaxRate`,
       `away`.`aw_ReceiptInvoice`.`invoiceType`                   AS `invoiceType`,
       `away`.`aw_ReceiptInvoice`.`purchaseUnitPriceExcludingTax` AS `purchaseUnitPriceExcludingTax`,
       `away`.`aw_ReceiptInvoice`.`purchaseUnitPriceIncludingTax` AS `purchaseUnitPriceIncludingTax`,
       `aw_BasicToolInformation`.`name`                           AS `name`,
       `aw_BasicToolInformation`.`toolPrice`                      AS `toolPrice`,
       `aw_BasicToolInformation`.`typeName`                       AS `typeName`,
       `aw_BasicToolInformation`.`specificationsType`             AS `specificationsType`,
       `aw_BasicToolInformation`.`specificationModel`             AS `specificationModel`,
       `aw_BasicToolInformation`.`uint`                           AS `uint`
from ((`away`.`aw_toolStorage` join `away`.`aw_BasicToolInformation` on ((`away`.`aw_toolStorage`.`toolInformationID` =
                                                                          `aw_BasicToolInformation`.`id`))) join `away`.`aw_ReceiptInvoice`
      on ((`away`.`aw_toolStorage`.`receiptInvoiceID` = `away`.`aw_ReceiptInvoice`.`receiptInvoiceID`)));

-- comment on column aw_DetailsOfToolStorage.id not supported: 刀具入库id

-- comment on column aw_DetailsOfToolStorage.warehouseEntryID not supported: 入库单编号

-- comment on column aw_DetailsOfToolStorage.receiptInvoiceID not supported: 发票信息编号

-- comment on column aw_DetailsOfToolStorage.toolInformationID not supported: 刀具基本信息

-- comment on column aw_DetailsOfToolStorage.receiptQuantity not supported: 入库数量

-- comment on column aw_DetailsOfToolStorage.manufacturers not supported: 厂商

-- comment on column aw_DetailsOfToolStorage.notes not supported: 备注

-- comment on column aw_DetailsOfToolStorage.invoiceTaxRate not supported: 发票税率

-- comment on column aw_DetailsOfToolStorage.invoiceType not supported: 发票类型

-- comment on column aw_DetailsOfToolStorage.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column aw_DetailsOfToolStorage.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column aw_DetailsOfToolStorage.name not supported: 刀具名称

-- comment on column aw_DetailsOfToolStorage.toolPrice not supported: 备注信息

-- comment on column aw_DetailsOfToolStorage.typeName not supported: 类别名称

-- comment on column aw_DetailsOfToolStorage.specificationsType not supported: 规格类型

-- comment on column aw_DetailsOfToolStorage.specificationModel not supported: 规格型号

-- comment on column aw_DetailsOfToolStorage.uint not supported: 计量单位

