create definer = away@`%` view aw_DetailCustomerMaterialsStorage as
select `away`.`aw_CustomerMaterialsStorage`.`id`               AS `id`,
       `away`.`aw_CustomerMaterialsStorage`.`saleorderID`      AS `saleorderID`,
       `away`.`aw_CustomerMaterialsStorage`.`materialID`       AS `materialID`,
       `away`.`aw_CustomerMaterialsStorage`.`warehouseEntryID` AS `warehouseEntryID`,
       `away`.`aw_CustomerMaterialsStorage`.`receiptQuantity`  AS `receiptQuantity`,
       `away`.`aw_CustomerMaterialsStorage`.`sampleURL`        AS `sampleURL`,
       `away`.`aw_CustomerMaterialsStorage`.`notes`            AS `notes`,
       `aw_BasicInformationOfMaterials`.`name`                 AS `materialName`,
       `aw_BasicInformationOfMaterials`.`typeID`               AS `typeID`,
       `aw_BasicInformationOfMaterials`.`specificationsID`     AS `specificationsID`,
       `aw_BasicInformationOfMaterials`.`materialDensity`      AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`materialPrice`        AS `materialPrice`,
       `aw_BasicInformationOfMaterials`.`typeName`             AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`   AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`   AS `specificationModel`,
       `aw_orderhoursdetailed`.`name`                          AS `partnerName`
from ((`away`.`aw_CustomerMaterialsStorage` join `away`.`aw_BasicInformationOfMaterials`
       on ((`away`.`aw_CustomerMaterialsStorage`.`materialID` =
            `aw_BasicInformationOfMaterials`.`id`))) join `away`.`aw_orderhoursdetailed`
      on ((`away`.`aw_CustomerMaterialsStorage`.`saleorderID` = `aw_orderhoursdetailed`.`id`)));

-- comment on column aw_DetailCustomerMaterialsStorage.saleorderID not supported: 订单编号

-- comment on column aw_DetailCustomerMaterialsStorage.materialID not supported: 材料基础信息编号

-- comment on column aw_DetailCustomerMaterialsStorage.warehouseEntryID not supported: 入库单编号

-- comment on column aw_DetailCustomerMaterialsStorage.receiptQuantity not supported: 入库数量

-- comment on column aw_DetailCustomerMaterialsStorage.sampleURL not supported: 附样

-- comment on column aw_DetailCustomerMaterialsStorage.notes not supported: 备注

-- comment on column aw_DetailCustomerMaterialsStorage.materialName not supported: 材料名称

-- comment on column aw_DetailCustomerMaterialsStorage.typeID not supported: 材料分类

-- comment on column aw_DetailCustomerMaterialsStorage.specificationsID not supported: 规格类型

-- comment on column aw_DetailCustomerMaterialsStorage.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_DetailCustomerMaterialsStorage.materialPrice not supported: 备注信息

-- comment on column aw_DetailCustomerMaterialsStorage.typeName not supported: 类别名称

-- comment on column aw_DetailCustomerMaterialsStorage.specificationsType not supported: 规格类型

-- comment on column aw_DetailCustomerMaterialsStorage.specificationModel not supported: 规格型号

-- comment on column aw_DetailCustomerMaterialsStorage.partnerName not supported: 实体姓名

