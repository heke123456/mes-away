create definer = away@`%` view aw_DetailDlvryCsmtMtls as
select `away`.`aw_DlvryCsmtMtls`.`id`                      AS `id`,
       `away`.`aw_DlvryCsmtMtls`.`deliverynotesID`         AS `deliverynotesID`,
       `away`.`aw_DlvryCsmtMtls`.`materialID`              AS `materialID`,
       `aw_BasicInformationOfMaterials`.`name`             AS `materialName`,
       `away`.`aw_ProductionTasks`.`productionTasksFormID` AS `productionTasksFormID`,
       `away`.`aw_DlvryCsmtMtls`.`productionTasksID`       AS `productionTasksID`,
       `away`.`aw_DlvryCsmtMtls`.`processingTechnologyID`  AS `processingTechnologyID`,
       `away`.`aw_ProcessRequirementMaterialList`.`id`     AS `prmID`,
       `away`.`aw_DlvryCsmtMtls`.`outboundQuantity`        AS `outboundQuantity`,
       `away`.`aw_DlvryCsmtMtls`.`notes`                   AS `notes`
from (((`away`.`aw_DlvryCsmtMtls` join `away`.`aw_BasicInformationOfMaterials`
        on ((`away`.`aw_DlvryCsmtMtls`.`materialID` =
             `aw_BasicInformationOfMaterials`.`id`))) join `away`.`aw_ProcessRequirementMaterialList`
       on ((`away`.`aw_DlvryCsmtMtls`.`processingTechnologyID` =
            `away`.`aw_ProcessRequirementMaterialList`.`processingTechnologyID`))) join `away`.`aw_ProductionTasks`
      on ((`away`.`aw_DlvryCsmtMtls`.`productionTasksID` = `away`.`aw_ProductionTasks`.`id`)));

-- comment on column aw_DetailDlvryCsmtMtls.id not supported: id

-- comment on column aw_DetailDlvryCsmtMtls.deliverynotesID not supported: 出库单编号

-- comment on column aw_DetailDlvryCsmtMtls.materialID not supported: 材料基础信息编号

-- comment on column aw_DetailDlvryCsmtMtls.materialName not supported: 材料名称

-- comment on column aw_DetailDlvryCsmtMtls.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_DetailDlvryCsmtMtls.productionTasksID not supported: 任务编号

-- comment on column aw_DetailDlvryCsmtMtls.processingTechnologyID not supported: 工艺编号

-- comment on column aw_DetailDlvryCsmtMtls.prmID not supported: id

-- comment on column aw_DetailDlvryCsmtMtls.outboundQuantity not supported: 出库数量

-- comment on column aw_DetailDlvryCsmtMtls.notes not supported: 备注

