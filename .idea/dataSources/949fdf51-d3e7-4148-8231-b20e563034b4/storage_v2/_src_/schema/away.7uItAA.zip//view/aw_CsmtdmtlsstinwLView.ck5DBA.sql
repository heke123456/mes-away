create definer = away@`%` view aw_CsmtdmtlsstinwLView as
select `away`.`aw_CsmtdmtlsstinwList`.`warehouseEntryID` AS `warehouseEntryID`,
       `away`.`aw_Warehousing`.`warehousingDate`         AS `warehousingDate`,
       `away`.`aw_Warehousing`.`creator`                 AS `creator`,
       `away`.`aw_Warehousing`.`acceptedBy`              AS `acceptedBy`,
       `away`.`aw_Warehousing`.`warehouseKeeper`         AS `warehouseKeeper`,
       `away`.`aw_Warehousing`.`operator`                AS `operator`,
       `away`.`aw_Warehousing`.`notes`                   AS `notes`,
       `away`.`aw_Warehousing`.`status`                  AS `status`
from (`away`.`aw_CsmtdmtlsstinwList` left join `away`.`aw_Warehousing`
      on ((`away`.`aw_CsmtdmtlsstinwList`.`warehouseEntryID` = `away`.`aw_Warehousing`.`warehouseEntryID`)));

-- comment on column aw_CsmtdmtlsstinwLView.warehouseEntryID not supported: 入库单编号

-- comment on column aw_CsmtdmtlsstinwLView.warehousingDate not supported: 入库日期

-- comment on column aw_CsmtdmtlsstinwLView.creator not supported: 制单人

-- comment on column aw_CsmtdmtlsstinwLView.acceptedBy not supported: 验收人

-- comment on column aw_CsmtdmtlsstinwLView.warehouseKeeper not supported: 库管员

-- comment on column aw_CsmtdmtlsstinwLView.operator not supported: 经办人

-- comment on column aw_CsmtdmtlsstinwLView.notes not supported: 备注

-- comment on column aw_CsmtdmtlsstinwLView.status not supported: 状态

