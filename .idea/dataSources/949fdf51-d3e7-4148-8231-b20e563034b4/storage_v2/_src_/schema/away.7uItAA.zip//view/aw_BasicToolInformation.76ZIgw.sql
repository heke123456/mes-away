create definer = away@`%` view aw_BasicToolInformation as
select `away`.`aw_toolInformation`.`id`                AS `id`,
       `away`.`aw_toolInformation`.`name`              AS `name`,
       `away`.`aw_toolInformation`.`typeID`            AS `typeID`,
       `away`.`aw_toolInformation`.`specificationsID`  AS `specificationsID`,
       `away`.`aw_toolInformation`.`unitID`            AS `unitID`,
       `away`.`aw_toolInformation`.`notes`             AS `toolPrice`,
       `away`.`aw_toolclassification`.`name`           AS `typeName`,
       `away`.`aw_units`.`unit`                        AS `uint`,
       `away`.`aw_specifications`.`type`               AS `specificationsType`,
       `away`.`aw_specifications`.`specificationModel` AS `specificationModel`
from (((`away`.`aw_toolInformation` join `away`.`aw_toolclassification`
        on ((`away`.`aw_toolInformation`.`typeID` = `away`.`aw_toolclassification`.`id`))) join `away`.`aw_units`
       on ((`away`.`aw_toolInformation`.`unitID` = `away`.`aw_units`.`id`))) join `away`.`aw_specifications`
      on ((`away`.`aw_toolInformation`.`specificationsID` = `away`.`aw_specifications`.`id`)));

-- comment on column aw_BasicToolInformation.id not supported: 刀具编号

-- comment on column aw_BasicToolInformation.name not supported: 刀具名称

-- comment on column aw_BasicToolInformation.typeID not supported: 刀具分类

-- comment on column aw_BasicToolInformation.specificationsID not supported: 刀具规格

-- comment on column aw_BasicToolInformation.unitID not supported: 计量单位id

-- comment on column aw_BasicToolInformation.toolPrice not supported: 备注信息

-- comment on column aw_BasicToolInformation.typeName not supported: 类别名称

-- comment on column aw_BasicToolInformation.uint not supported: 计量单位

-- comment on column aw_BasicToolInformation.specificationsType not supported: 规格类型

-- comment on column aw_BasicToolInformation.specificationModel not supported: 规格型号

