create definer = away@`%` view aw_DetailProductWarehousing as
select `away`.`aw_ProductStorage`.`id`                          AS `id`,
       `away`.`aw_ProductStorage`.`warehouseEntryID`            AS `warehouseEntryID`,
       `away`.`aw_ProductStorage`.`productID`                   AS `productID`,
       `away`.`aw_ProductStorage`.`receiptQuantity`             AS `receiptQuantity`,
       `away`.`aw_ProductStorage`.`FinishedProductInspectionID` AS `FinishedProductInspectionID`,
       `away`.`aw_FinishedProductInspection`.`testResult`       AS `testResult`,
       `away`.`aw_ProductStorage`.`notes`                       AS `notes`
from (`away`.`aw_ProductStorage` left join `away`.`aw_FinishedProductInspection`
      on ((`away`.`aw_ProductStorage`.`FinishedProductInspectionID` = `away`.`aw_FinishedProductInspection`.`id`)));

-- comment on column aw_DetailProductWarehousing.id not supported: id

-- comment on column aw_DetailProductWarehousing.warehouseEntryID not supported: 产品入库单编号

-- comment on column aw_DetailProductWarehousing.productID not supported: 产品图号

-- comment on column aw_DetailProductWarehousing.receiptQuantity not supported: 入库数量

-- comment on column aw_DetailProductWarehousing.FinishedProductInspectionID not supported: 成品检验编号

-- comment on column aw_DetailProductWarehousing.testResult not supported: 检测结果

-- comment on column aw_DetailProductWarehousing.notes not supported: 备注

