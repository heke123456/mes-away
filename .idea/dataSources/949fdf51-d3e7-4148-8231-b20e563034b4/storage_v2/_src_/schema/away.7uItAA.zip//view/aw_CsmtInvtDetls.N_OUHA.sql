create definer = away@`%` view aw_CsmtInvtDetls as
select `away`.`aw_customersuppliedmaterials`.`id`            AS `id`,
       `away`.`aw_customersuppliedmaterials`.`saleorderID`   AS `saleorderID`,
       `away`.`aw_customersuppliedmaterials`.`materialID`    AS `materialID`,
       `away`.`aw_customersuppliedmaterials`.`number`        AS `number`,
       `away`.`aw_customersuppliedmaterials`.`weight`        AS `weight`,
       `aw_BasicInformationOfMaterials`.`name`               AS `materianame`,
       `aw_BasicInformationOfMaterials`.`typeName`           AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType` AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel` AS `specificationModel`,
       `aw_BasicInformationOfMaterials`.`materialDensity`    AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`materialPrice`      AS `notes`,
       `aw_SalesOrderDetails`.`name`                         AS `customname`
from ((`away`.`aw_customersuppliedmaterials` left join `away`.`aw_BasicInformationOfMaterials`
       on ((`away`.`aw_customersuppliedmaterials`.`materialID` =
            `aw_BasicInformationOfMaterials`.`id`))) left join `away`.`aw_SalesOrderDetails`
      on ((`away`.`aw_customersuppliedmaterials`.`saleorderID` = `aw_SalesOrderDetails`.`id`)));

-- comment on column aw_CsmtInvtDetls.id not supported: 材料库存id

-- comment on column aw_CsmtInvtDetls.saleorderID not supported: 销售订单编号

-- comment on column aw_CsmtInvtDetls.materialID not supported: 材料基本信息id

-- comment on column aw_CsmtInvtDetls.number not supported: 材料库存数量

-- comment on column aw_CsmtInvtDetls.weight not supported: 材料库存重量

-- comment on column aw_CsmtInvtDetls.materianame not supported: 材料名称

-- comment on column aw_CsmtInvtDetls.typeName not supported: 类别名称

-- comment on column aw_CsmtInvtDetls.specificationsType not supported: 规格类型

-- comment on column aw_CsmtInvtDetls.specificationModel not supported: 规格型号

-- comment on column aw_CsmtInvtDetls.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_CsmtInvtDetls.notes not supported: 备注信息

-- comment on column aw_CsmtInvtDetls.customname not supported: 实体姓名

