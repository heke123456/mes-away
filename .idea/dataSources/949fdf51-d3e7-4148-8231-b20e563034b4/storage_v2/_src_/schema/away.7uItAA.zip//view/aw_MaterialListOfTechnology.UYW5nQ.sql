create definer = away@`%` view aw_MaterialListOfTechnology as
select `away`.`aw_ProcessRequirementMaterialList`.`id`                     AS `id`,
       `away`.`aw_ProcessRequirementMaterialList`.`materialID`             AS `materialID`,
       `away`.`aw_ProcessRequirementMaterialList`.`processingTechnologyID` AS `processingTechnologyID`,
       `aw_BasicInformationOfMaterials`.`name`                             AS `name`,
       `aw_BasicInformationOfMaterials`.`materialPrice`                    AS `materialPrice`,
       `aw_BasicInformationOfMaterials`.`materialDensity`                  AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`typeName`                         AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`               AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`               AS `specificationModel`,
       `away`.`aw_ProcessRequirementMaterialList`.`cuttingSize`            AS `cuttingSize`,
       `away`.`aw_ProcessRequirementMaterialList`.`numberProducibleParts`  AS `numberProducibleParts`
from (`away`.`aw_ProcessRequirementMaterialList` join `away`.`aw_BasicInformationOfMaterials`
      on ((`away`.`aw_ProcessRequirementMaterialList`.`materialID` = `aw_BasicInformationOfMaterials`.`id`)));

-- comment on column aw_MaterialListOfTechnology.id not supported: id

-- comment on column aw_MaterialListOfTechnology.materialID not supported: 材料基础信息编号

-- comment on column aw_MaterialListOfTechnology.processingTechnologyID not supported: 工艺编号

-- comment on column aw_MaterialListOfTechnology.name not supported: 材料名称

-- comment on column aw_MaterialListOfTechnology.materialPrice not supported: 备注信息

-- comment on column aw_MaterialListOfTechnology.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_MaterialListOfTechnology.typeName not supported: 类别名称

-- comment on column aw_MaterialListOfTechnology.specificationsType not supported: 规格类型

-- comment on column aw_MaterialListOfTechnology.specificationModel not supported: 规格型号

-- comment on column aw_MaterialListOfTechnology.cuttingSize not supported: 下料尺寸

-- comment on column aw_MaterialListOfTechnology.numberProducibleParts not supported: 可制件数

