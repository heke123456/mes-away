create definer = away@`%` view aw_MatlOutboundDet as
select `away`.`aw_LocalMaterialOutbound`.`id`                     AS `id`,
       `away`.`aw_LocalMaterialOutbound`.`deliveryNoteID`         AS `deliveryNoteID`,
       `away`.`aw_LocalMaterialOutbound`.`materialID`             AS `materialID`,
       `aw_BasicInformationOfMaterials`.`name`                    AS `name`,
       `aw_BasicInformationOfMaterials`.`materialPrice`           AS `materialPrice`,
       `aw_BasicInformationOfMaterials`.`typeName`                AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`      AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`      AS `specificationModel`,
       `away`.`aw_LocalMaterialOutbound`.`productionTasksID`      AS `productionTasksID`,
       `away`.`aw_LocalMaterialOutbound`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_LocalMaterialOutbound`.`outboundQuantity`       AS `outboundQuantity`,
       `away`.`aw_LocalMaterialOutbound`.`notes`                  AS `notes`
from (`away`.`aw_LocalMaterialOutbound` join `away`.`aw_BasicInformationOfMaterials`
      on ((`away`.`aw_LocalMaterialOutbound`.`materialID` = `aw_BasicInformationOfMaterials`.`id`)));

-- comment on column aw_MatlOutboundDet.id not supported: id

-- comment on column aw_MatlOutboundDet.deliveryNoteID not supported: 出库单编号

-- comment on column aw_MatlOutboundDet.materialID not supported: 材料基础信息编号

-- comment on column aw_MatlOutboundDet.name not supported: 材料名称

-- comment on column aw_MatlOutboundDet.materialPrice not supported: 备注信息

-- comment on column aw_MatlOutboundDet.typeName not supported: 类别名称

-- comment on column aw_MatlOutboundDet.specificationsType not supported: 规格类型

-- comment on column aw_MatlOutboundDet.specificationModel not supported: 规格型号

-- comment on column aw_MatlOutboundDet.productionTasksID not supported: 任务编号

-- comment on column aw_MatlOutboundDet.processingTechnologyID not supported: 工艺编号

-- comment on column aw_MatlOutboundDet.outboundQuantity not supported: 出库数量

-- comment on column aw_MatlOutboundDet.notes not supported: 备注

