create definer = away@`%` view aw_DetailProductOutbound as
select `away`.`aw_ProductOutbound`.`id`              AS `id`,
       `away`.`aw_ProductOutbound`.`deliveryNoteID`  AS `deliveryNoteID`,
       `away`.`aw_ProductOutbound`.`productID`       AS `productID`,
       `away`.`aw_ProductOutbound`.`receiptQuantity` AS `receiptQuantity`,
       `away`.`aw_ProductOutbound`.`contractID`      AS `contractID`,
       `away`.`aw_ProductOutbound`.`notes`           AS `notes`,
       `away`.`aw_product`.`name`                    AS `customname`,
       `away`.`aw_partner`.`name`                    AS `productname`
from ((`away`.`aw_ProductOutbound` join `away`.`aw_product`
       on ((`away`.`aw_ProductOutbound`.`productID` = `away`.`aw_product`.`id`))) join `away`.`aw_partner`
      on ((`away`.`aw_ProductOutbound`.`contractID` = `away`.`aw_partner`.`id`)));

-- comment on column aw_DetailProductOutbound.id not supported: id

-- comment on column aw_DetailProductOutbound.deliveryNoteID not supported: 出库单编号

-- comment on column aw_DetailProductOutbound.productID not supported: 产品图号

-- comment on column aw_DetailProductOutbound.receiptQuantity not supported: 出库数量

-- comment on column aw_DetailProductOutbound.contractID not supported: 客户编号

-- comment on column aw_DetailProductOutbound.notes not supported: 备注

-- comment on column aw_DetailProductOutbound.customname not supported: 产品名称

-- comment on column aw_DetailProductOutbound.productname not supported: 实体姓名

