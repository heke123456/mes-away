create definer = away@`%` view aw_DetailCustomerMaterialOutbound as
select `away`.`aw_CustomerMaterialsOutbound`.`id`                     AS `id`,
       `away`.`aw_CustomerMaterialsOutbound`.`deliveryNoteID`         AS `deliveryNoteID`,
       `away`.`aw_CustomerMaterialsOutbound`.`materialID`             AS `materialID`,
       `away`.`aw_CustomerMaterialsOutbound`.`productionTasksID`      AS `productionTasksID`,
       `away`.`aw_CustomerMaterialsOutbound`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_CustomerMaterialsOutbound`.`outboundQuantity`       AS `outboundQuantity`,
       `away`.`aw_CustomerMaterialsOutbound`.`notes`                  AS `notes`,
       `aw_BasicInformationOfMaterials`.`name`                        AS `name`,
       `aw_BasicInformationOfMaterials`.`materialPrice`               AS `materialPrice`,
       `aw_BasicInformationOfMaterials`.`materialDensity`             AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`typeName`                    AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`          AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`          AS `specificationModel`
from (`away`.`aw_CustomerMaterialsOutbound` join `away`.`aw_BasicInformationOfMaterials`
      on ((`away`.`aw_CustomerMaterialsOutbound`.`materialID` = `aw_BasicInformationOfMaterials`.`id`)));

-- comment on column aw_DetailCustomerMaterialOutbound.id not supported: id

-- comment on column aw_DetailCustomerMaterialOutbound.deliveryNoteID not supported: 出库单编号

-- comment on column aw_DetailCustomerMaterialOutbound.materialID not supported: 材料基础信息编号

-- comment on column aw_DetailCustomerMaterialOutbound.productionTasksID not supported: 任务编号

-- comment on column aw_DetailCustomerMaterialOutbound.processingTechnologyID not supported: 工艺编号

-- comment on column aw_DetailCustomerMaterialOutbound.outboundQuantity not supported: 出库数量

-- comment on column aw_DetailCustomerMaterialOutbound.notes not supported: 备注

-- comment on column aw_DetailCustomerMaterialOutbound.name not supported: 材料名称

-- comment on column aw_DetailCustomerMaterialOutbound.materialPrice not supported: 备注信息

-- comment on column aw_DetailCustomerMaterialOutbound.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_DetailCustomerMaterialOutbound.typeName not supported: 类别名称

-- comment on column aw_DetailCustomerMaterialOutbound.specificationsType not supported: 规格类型

-- comment on column aw_DetailCustomerMaterialOutbound.specificationModel not supported: 规格型号

