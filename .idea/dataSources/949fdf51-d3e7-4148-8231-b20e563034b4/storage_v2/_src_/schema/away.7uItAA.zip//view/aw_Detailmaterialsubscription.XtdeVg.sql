create definer = away@`%` view aw_Detailmaterialsubscription as
select `away`.`aw_MaterialSubscription`.`materialSubscription`   AS `materialSubscription`,
       `away`.`aw_MaterialSubscription`.`subscribeID`            AS `subscribeID`,
       `away`.`aw_MaterialSubscription`.`productionTasksID`      AS `productionTasksID`,
       `away`.`aw_MaterialSubscription`.`materialID`             AS `materialID`,
       `aw_BasicInformationOfMaterials`.`name`                   AS `name`,
       `aw_BasicInformationOfMaterials`.`materialPrice`          AS `materialPrice`,
       `aw_BasicInformationOfMaterials`.`typeName`               AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`     AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`     AS `specificationModel`,
       `aw_BasicInformationOfMaterials`.`materialDensity`        AS `materialDensity`,
       `away`.`aw_MaterialSubscription`.`processingTechnologyID` AS `processingTechnologyID`,
       `away`.`aw_MaterialSubscription`.`subscriptionQuantity`   AS `subscriptionQuantity`,
       `away`.`aw_MaterialSubscription`.`requiredDate`           AS `requiredDate`,
       `away`.`aw_MaterialSubscription`.`sampleURL`              AS `sampleURL`,
       `away`.`aw_MaterialSubscription`.`note`                   AS `note`
from (`away`.`aw_MaterialSubscription` join `away`.`aw_BasicInformationOfMaterials`
      on ((`away`.`aw_MaterialSubscription`.`materialID` = `aw_BasicInformationOfMaterials`.`id`)));

-- comment on column aw_Detailmaterialsubscription.materialSubscription not supported: 申购材料编号

-- comment on column aw_Detailmaterialsubscription.subscribeID not supported: 申购单编号

-- comment on column aw_Detailmaterialsubscription.productionTasksID not supported: 任务编号

-- comment on column aw_Detailmaterialsubscription.materialID not supported: 材料基础信息编号

-- comment on column aw_Detailmaterialsubscription.name not supported: 材料名称

-- comment on column aw_Detailmaterialsubscription.materialPrice not supported: 备注信息

-- comment on column aw_Detailmaterialsubscription.typeName not supported: 类别名称

-- comment on column aw_Detailmaterialsubscription.specificationsType not supported: 规格类型

-- comment on column aw_Detailmaterialsubscription.specificationModel not supported: 规格型号

-- comment on column aw_Detailmaterialsubscription.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_Detailmaterialsubscription.processingTechnologyID not supported: 工艺编号

-- comment on column aw_Detailmaterialsubscription.subscriptionQuantity not supported: 申购数量

-- comment on column aw_Detailmaterialsubscription.requiredDate not supported: 需用日期

-- comment on column aw_Detailmaterialsubscription.sampleURL not supported: 附样

-- comment on column aw_Detailmaterialsubscription.note not supported: 备注

