create definer = away@`%` view aw_DetailReconciliation as
select `away`.`aw_Reconciliation`.`id`                       AS `id`,
       `away`.`aw_Reconciliation`.`statementOfAccountID`     AS `statementOfAccountID`,
       `away`.`aw_Reconciliation`.`saleorderID`              AS `saleorderID`,
       `aw_BasicOrderInformation`.`money`                    AS `money`,
       `aw_BasicOrderInformation`.`name`                     AS `name`,
       `aw_BasicOrderInformation`.`productName`              AS `productName`,
       `aw_BasicOrderInformation`.`number`                   AS `number`,
       `away`.`aw_Reconciliation`.`numberOfProductsSupplied` AS `numberOfProductsSupplied`,
       `away`.`aw_Reconciliation`.`orderAmount`              AS `orderAmount`,
       `away`.`aw_Reconciliation`.`amountDue`                AS `amountDue`,
       `away`.`aw_Reconciliation`.`outOfPocketAmount`        AS `outOfPocketAmount`,
       `away`.`aw_Reconciliation`.`unpaidAmount`             AS `unpaidAmount`,
       `away`.`aw_Reconciliation`.`notes`                    AS `notes`,
       `away`.`aw_Reconciliation`.`status`                   AS `status`,
       `away`.`aw_Reconciliation`.`customerPrice`            AS `customerPrice`,
       `away`.`aw_Reconciliation`.`invoicePrice`             AS `invoicePrice`,
       `away`.`aw_Reconciliation`.`processPrice`             AS `processPrice`
from (`away`.`aw_Reconciliation` join `away`.`aw_BasicOrderInformation`
      on ((`away`.`aw_Reconciliation`.`saleorderID` = `aw_BasicOrderInformation`.`id`)));

-- comment on column aw_DetailReconciliation.id not supported: 对账id

-- comment on column aw_DetailReconciliation.statementOfAccountID not supported: 对账单Id

-- comment on column aw_DetailReconciliation.saleorderID not supported: 订单id

-- comment on column aw_DetailReconciliation.money not supported: 合同金额

-- comment on column aw_DetailReconciliation.name not supported: 实体姓名

-- comment on column aw_DetailReconciliation.productName not supported: 产品名称

-- comment on column aw_DetailReconciliation.number not supported: 需求数量#要求大于0#

-- comment on column aw_DetailReconciliation.numberOfProductsSupplied not supported: 以供产品数

-- comment on column aw_DetailReconciliation.orderAmount not supported: 订单金额

-- comment on column aw_DetailReconciliation.amountDue not supported: 应付金额

-- comment on column aw_DetailReconciliation.outOfPocketAmount not supported: 实付金额

-- comment on column aw_DetailReconciliation.unpaidAmount not supported: 未付金额

-- comment on column aw_DetailReconciliation.notes not supported: 备注

-- comment on column aw_DetailReconciliation.status not supported: 是否通过

-- comment on column aw_DetailReconciliation.customerPrice not supported: 客户价格

-- comment on column aw_DetailReconciliation.invoicePrice not supported: 发票价格

-- comment on column aw_DetailReconciliation.processPrice not supported: 工艺价格

