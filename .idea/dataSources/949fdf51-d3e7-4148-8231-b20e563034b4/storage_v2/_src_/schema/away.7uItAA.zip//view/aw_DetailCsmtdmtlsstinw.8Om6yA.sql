create definer = away@`%` view aw_DetailCsmtdmtlsstinw as
select `away`.`aw_Csmtdmtlsstinw`.`id`                     AS `id`,
       `away`.`aw_Csmtdmtlsstinw`.`warehouseEntryID`       AS `warehouseEntryID`,
       `away`.`aw_Csmtdmtlsstinw`.`materialID`             AS `materialID`,
       `aw_BasicInformationOfMaterials`.`name`             AS `materialName`,
       `away`.`aw_Csmtdmtlsstinw`.`mthd`                   AS `mthd`,
       `away`.`aw_Csmtdmtlsstinw`.`furnaceBatchNumber`     AS `furnaceBatchNumber`,
       `away`.`aw_Csmtdmtlsstinw`.`dataType`               AS `dataType`,
       `away`.`aw_Csmtdmtlsstinw`.`dataAttachment`         AS `dataAttachment`,
       `away`.`aw_Csmtdmtlsstinw`.`receiptQuantity`        AS `receiptQuantity`,
       `away`.`aw_ProductionTasks`.`productionTasksFormID` AS `productionTasksFormID`,
       `away`.`aw_Csmtdmtlsstinw`.`productionTasksID`      AS `productionTasksID`,
       `aw_SalesOrderDetails`.`customerID`                 AS `customerID`,
       `aw_SalesOrderDetails`.`name`                       AS `customername`,
       `aw_SalesOrderDetails`.`productID`                  AS `productID`,
       `aw_SalesOrderDetails`.`productName`                AS `productName`,
       `away`.`aw_Csmtdmtlsstinw`.`sampleURL`              AS `sampleURL`,
       `away`.`aw_Csmtdmtlsstinw`.`notes`                  AS `notes`
from (((`away`.`aw_Csmtdmtlsstinw` join `away`.`aw_BasicInformationOfMaterials`
        on ((`away`.`aw_Csmtdmtlsstinw`.`materialID` =
             `aw_BasicInformationOfMaterials`.`id`))) join `away`.`aw_ProductionTasks`
       on ((`away`.`aw_Csmtdmtlsstinw`.`productionTasksID` =
            `away`.`aw_ProductionTasks`.`id`))) join `away`.`aw_SalesOrderDetails`
      on ((`away`.`aw_ProductionTasks`.`saleOrderID` = `aw_SalesOrderDetails`.`id`)));

-- comment on column aw_DetailCsmtdmtlsstinw.id not supported: id

-- comment on column aw_DetailCsmtdmtlsstinw.warehouseEntryID not supported: 入库单编号

-- comment on column aw_DetailCsmtdmtlsstinw.materialID not supported: 材料信息编号

-- comment on column aw_DetailCsmtdmtlsstinw.materialName not supported: 材料名称

-- comment on column aw_DetailCsmtdmtlsstinw.mthd not supported: 化验号

-- comment on column aw_DetailCsmtdmtlsstinw.furnaceBatchNumber not supported: 炉批号

-- comment on column aw_DetailCsmtdmtlsstinw.dataType not supported: 资料类型

-- comment on column aw_DetailCsmtdmtlsstinw.dataAttachment not supported: 资料附件

-- comment on column aw_DetailCsmtdmtlsstinw.receiptQuantity not supported: 入库数量

-- comment on column aw_DetailCsmtdmtlsstinw.productionTasksFormID not supported: 生产任务单编号

-- comment on column aw_DetailCsmtdmtlsstinw.productionTasksID not supported: 任务编号

-- comment on column aw_DetailCsmtdmtlsstinw.customerID not supported: 客户信息

-- comment on column aw_DetailCsmtdmtlsstinw.customername not supported: 实体姓名

-- comment on column aw_DetailCsmtdmtlsstinw.productID not supported: 产品信息

-- comment on column aw_DetailCsmtdmtlsstinw.productName not supported: 产品名称

-- comment on column aw_DetailCsmtdmtlsstinw.sampleURL not supported: 附样

-- comment on column aw_DetailCsmtdmtlsstinw.notes not supported: 备注

