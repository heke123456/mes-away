create definer = away@`%` view aw_MatlWarehousingDet as
select `away`.`aw_LocalMaterialWarehousing`.`id`                   AS `id`,
       `away`.`aw_LocalMaterialWarehousing`.`warehouseEntryID`     AS `warehouseEntryID`,
       `away`.`aw_LocalMaterialWarehousing`.`materialSubscription` AS `materialSubscription`,
       `away`.`aw_LocalMaterialWarehousing`.`materialID`           AS `materialID`,
       `aw_BasicInformationOfMaterials`.`name`                     AS `name`,
       `aw_BasicInformationOfMaterials`.`typeName`                 AS `typeName`,
       `aw_BasicInformationOfMaterials`.`specificationsType`       AS `specificationsType`,
       `aw_BasicInformationOfMaterials`.`specificationModel`       AS `specificationModel`,
       `aw_BasicInformationOfMaterials`.`materialDensity`          AS `materialDensity`,
       `aw_BasicInformationOfMaterials`.`materialPrice`            AS `materialPrice`,
       `away`.`aw_LocalMaterialWarehousing`.`receiptInvoiceID`     AS `receiptInvoiceID`,
       `away`.`aw_ReceiptInvoice`.`invoiceType`                    AS `invoiceType`,
       `away`.`aw_ReceiptInvoice`.`invoiceTaxRate`                 AS `invoiceTaxRate`,
       `away`.`aw_ReceiptInvoice`.`purchaseUnitPriceExcludingTax`  AS `purchaseUnitPriceExcludingTax`,
       `away`.`aw_ReceiptInvoice`.`purchaseUnitPriceIncludingTax`  AS `purchaseUnitPriceIncludingTax`,
       `away`.`aw_LocalMaterialWarehousing`.`receiptQuantity`      AS `receiptQuantity`,
       `away`.`aw_LocalMaterialWarehousing`.`sampleURL`            AS `sampleURL`,
       `away`.`aw_LocalMaterialWarehousing`.`notes`                AS `notes`
from ((`away`.`aw_LocalMaterialWarehousing` join `away`.`aw_ReceiptInvoice`
       on ((`away`.`aw_LocalMaterialWarehousing`.`receiptInvoiceID` =
            `away`.`aw_ReceiptInvoice`.`receiptInvoiceID`))) join `away`.`aw_BasicInformationOfMaterials`
      on ((`away`.`aw_LocalMaterialWarehousing`.`materialID` = `aw_BasicInformationOfMaterials`.`id`)));

-- comment on column aw_MatlWarehousingDet.id not supported: id

-- comment on column aw_MatlWarehousingDet.warehouseEntryID not supported: 入库单编号

-- comment on column aw_MatlWarehousingDet.materialSubscription not supported: 申购材料编号

-- comment on column aw_MatlWarehousingDet.materialID not supported: 材料基础信息编号

-- comment on column aw_MatlWarehousingDet.name not supported: 材料名称

-- comment on column aw_MatlWarehousingDet.typeName not supported: 类别名称

-- comment on column aw_MatlWarehousingDet.specificationsType not supported: 规格类型

-- comment on column aw_MatlWarehousingDet.specificationModel not supported: 规格型号

-- comment on column aw_MatlWarehousingDet.materialDensity not supported: 材料密度#校验大于0，用于工艺下料后自动计算重量。规格类型确定了重量计算公式。材料计数单位都以kg计，材料密度单位为kg/mm^3，材料尺寸单位为mm#

-- comment on column aw_MatlWarehousingDet.materialPrice not supported: 备注信息

-- comment on column aw_MatlWarehousingDet.receiptInvoiceID not supported: 发票信息编号

-- comment on column aw_MatlWarehousingDet.invoiceType not supported: 发票类型

-- comment on column aw_MatlWarehousingDet.invoiceTaxRate not supported: 发票税率

-- comment on column aw_MatlWarehousingDet.purchaseUnitPriceExcludingTax not supported: 不含税采购单价

-- comment on column aw_MatlWarehousingDet.purchaseUnitPriceIncludingTax not supported: 含税采购单价

-- comment on column aw_MatlWarehousingDet.receiptQuantity not supported: 入库数量

-- comment on column aw_MatlWarehousingDet.sampleURL not supported: 附样

-- comment on column aw_MatlWarehousingDet.notes not supported: 备注

